import org.apache.commons.io.FileUtils;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class MainPageTest {

    public static void main(String[] args) throws MalformedURLException {
        System.setProperty("webdriver.chrome.driver", "c:\\chromedrivers\\111.0.5563.64\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        WebDriver driver = new ChromeDriver(options);

        //test
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        driver.get("https://www.jetbrains.com/");
        takeScreenshot("landing", driver);

        WebElement searchButton = driver.findElement(By.cssSelector("[data-test='site-header-search-action']"));
        searchButton.click();

        WebElement searchField = driver.findElement(By.cssSelector("[data-test='search-input']"));
        searchField.sendKeys("Selenium");
        takeScreenshot("searchField", driver);

        WebElement submitButton = driver.findElement(By.cssSelector("button[data-test='full-search-button']"));
        submitButton.click();

        WebElement searchPageField = driver.findElement(By.cssSelector("input[data-test='search-input']"));
        takeScreenshot("searchPageField", driver);

        //end session and terminate browser machine
        driver.quit();
    }

    public static void takeScreenshot(String screenshotFileName, WebDriver driver){
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(screenshotFile, new File("c:\\tmp\\" + screenshotFileName + ".png"));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}